# WP Sports Picks Manager

Plugin WordPress para gerenciamento de picks de apostas esportivas integrado com Supabase/Lovable Cloud.

## Funcionalidades

- ✅ Gerenciamento completo de eventos esportivos
- ✅ Sistema de picks com análises
- ✅ Integração com API Supabase
- ✅ Shortcodes para exibição de picks
- ✅ Sistema multisite
- ✅ Suporte a múltiplos esportes e ligas

## Instalação

1. Faça upload da pasta `wp-sports-picks-manager` para `/wp-content/plugins/`
2. Ative o plugin através do menu 'Plugins' no WordPress
3. Vá para Sports Picks → Settings e configure sua API Supabase

## Configuração

### Obter credenciais Supabase

1. Acesse o dashboard do seu projeto Supabase
2. Navegue até Settings → API
3. Copie a "Project URL" (ex: https://xxxx.supabase.co)
4. Copie a "anon public" key
5. Cole essas informações na página de Settings do plugin

### Selecionar site padrão

Após configurar a API, selecione o site padrão onde o conteúdo será publicado.

## Uso

### Shortcodes disponíveis

#### [sports_picks]
Exibe uma lista de picks de eventos futuros.

**Atributos:**
- `site_id` - Filtrar por ID do site (opcional)
- `sport` - Filtrar por esporte (opcional)
- `limit` - Número máximo de eventos (padrão: 10)
- `layout` - Layout de exibição: 'grid' ou 'list' (padrão: 'grid')

**Exemplos:**
```
[sports_picks limit="5" layout="grid"]
[sports_picks site_id="uuid-do-site" limit="10"]
```

#### [event_card]
Exibe um card de evento específico.

**Atributos:**
- `event_id` - ID do evento (obrigatório)
- `show_picks` - Mostrar picks (padrão: 'true')

**Exemplo:**
```
[event_card event_id="uuid-do-evento"]
```

## Estrutura do Plugin

```
wp-sports-picks-manager/
├── wp-sports-picks-manager.php (arquivo principal)
├── includes/
│   ├── class-api-client.php (cliente API)
│   ├── class-admin-menu.php (menus admin)
│   └── class-shortcodes.php (shortcodes)
├── admin/
│   ├── views/
│   │   └── settings.php
│   └── assets/
│       └── css/
└── public/
    └── assets/
        └── css/
            └── styles.css
```

## Requisitos

- WordPress 5.0+
- PHP 7.4+
- Projeto Supabase configurado

## Suporte

Para suporte, abra uma issue no repositório GitHub ou entre em contato através do email de suporte.

## Licença

GPL v2 or later
