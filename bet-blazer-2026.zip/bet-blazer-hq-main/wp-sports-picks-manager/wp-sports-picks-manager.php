<?php
/**
 * Plugin Name: WP Sports Picks Manager
 * Plugin URI: https://github.com/yourusername/wp-sports-picks-manager
 * Description: Gerenciamento completo de picks de apostas esportivas integrado com Supabase
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-sports-picks-manager
 */

// Evitar acesso direto
if (!defined('ABSPATH')) {
    exit;
}

// Constantes do plugin
define('SPM_VERSION', '1.0.0');
define('SPM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SPM_PLUGIN_URL', plugin_dir_url(__FILE__));

// Classe principal do plugin
class WP_Sports_Picks_Manager {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }

    private function load_dependencies() {
        require_once SPM_PLUGIN_DIR . 'includes/class-api-client.php';
        require_once SPM_PLUGIN_DIR . 'includes/class-admin-menu.php';
        require_once SPM_PLUGIN_DIR . 'includes/class-shortcodes.php';
    }

    private function init_hooks() {
        add_action('admin_menu', array('SPM_Admin_Menu', 'register_menus'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_public_assets'));
        
        // Registrar shortcodes
        SPM_Shortcodes::register();
        
        // Hook de ativação
        register_activation_hook(__FILE__, array($this, 'activate'));
    }

    public function activate() {
        // Criar opções padrão
        add_option('spm_api_url', '');
        add_option('spm_api_key', '');
        add_option('spm_default_site_id', '');
    }

    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'sports-picks') === false) {
            return;
        }

        wp_enqueue_style(
            'spm-admin-styles',
            SPM_PLUGIN_URL . 'admin/assets/css/admin-styles.css',
            array(),
            SPM_VERSION
        );

        wp_enqueue_script(
            'spm-admin-scripts',
            SPM_PLUGIN_URL . 'admin/assets/js/admin-scripts.js',
            array('jquery'),
            SPM_VERSION,
            true
        );

        wp_localize_script('spm-admin-scripts', 'spmAdmin', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('spm_admin_nonce')
        ));
    }

    public function enqueue_public_assets() {
        wp_enqueue_style(
            'spm-public-styles',
            SPM_PLUGIN_URL . 'public/assets/css/styles.css',
            array(),
            SPM_VERSION
        );
    }
}

// Inicializar o plugin
function spm_init() {
    return WP_Sports_Picks_Manager::get_instance();
}
add_action('plugins_loaded', 'spm_init');
