<?php
/**
 * Cliente API para comunicação com Supabase Edge Functions
 */

class SPM_API_Client {
    private $api_url;
    private $api_key;

    public function __construct() {
        $this->api_url = get_option('spm_api_url');
        $this->api_key = get_option('spm_api_key');
    }

    private function get_headers() {
        return array(
            'apikey' => $this->api_key,
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type' => 'application/json'
        );
    }

    private function get_functions_url() {
        // Convert REST API URL to Functions URL
        // From: https://xxx.supabase.co
        // To: https://xxx.supabase.co/functions/v1
        $base_url = rtrim($this->api_url, '/');
        return $base_url . '/functions/v1';
    }

    private function make_request($endpoint, $method = 'GET', $body = null, $query_params = array()) {
        $url = $this->get_functions_url() . '/' . $endpoint;
        
        // Add query params
        if (!empty($query_params)) {
            $url .= '?' . http_build_query($query_params);
        }
        
        $args = array(
            'method' => $method,
            'headers' => $this->get_headers(),
            'timeout' => 30
        );

        if ($body && in_array($method, array('POST', 'PATCH', 'PUT', 'DELETE'))) {
            $args['body'] = json_encode($body);
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return array('error' => $response->get_error_message());
        }

        $response_body = wp_remote_retrieve_body($response);
        $code = wp_remote_retrieve_response_code($response);

        if ($code >= 400) {
            $error_data = json_decode($response_body, true);
            return array('error' => isset($error_data['error']) ? $error_data['error'] : 'HTTP Error ' . $code);
        }

        return json_decode($response_body, true);
    }

    // Sites
    public function get_sites() {
        return $this->make_request('api-sites');
    }

    // Sports
    public function get_sports($language = 'en') {
        return $this->make_request('api-sports', 'GET', null, array('language' => $language));
    }

    // Leagues
    public function get_leagues($sport_id = null, $language = 'en', $limit = 100, $offset = 0) {
        $params = array(
            'language' => $language,
            'limit' => $limit,
            'offset' => $offset
        );
        if ($sport_id) {
            $params['sport_id'] = $sport_id;
        }
        return $this->make_request('api-leagues', 'GET', null, $params);
    }

    // Teams
    public function get_teams($league_id = null, $sport_id = null, $language = 'en', $limit = 100, $offset = 0) {
        $params = array(
            'language' => $language,
            'limit' => $limit,
            'offset' => $offset
        );
        if ($league_id) {
            $params['league_id'] = $league_id;
        }
        if ($sport_id) {
            $params['sport_id'] = $sport_id;
        }
        return $this->make_request('api-teams', 'GET', null, $params);
    }

    // Events
    public function get_events($filters = array()) {
        $params = array(
            'language' => isset($filters['language']) ? $filters['language'] : 'en',
            'limit' => isset($filters['limit']) ? $filters['limit'] : 50,
            'offset' => isset($filters['offset']) ? $filters['offset'] : 0
        );
        
        if (isset($filters['site_id'])) {
            $params['site_id'] = $filters['site_id'];
        }
        if (isset($filters['sport_id'])) {
            $params['sport_id'] = $filters['sport_id'];
        }
        if (isset($filters['league_id'])) {
            $params['league_id'] = $filters['league_id'];
        }
        if (isset($filters['from_date'])) {
            $params['from_date'] = $filters['from_date'];
        }
        if (isset($filters['to_date'])) {
            $params['to_date'] = $filters['to_date'];
        }

        return $this->make_request('api-events', 'GET', null, $params);
    }

    public function create_event($data) {
        return $this->make_request('api-events', 'POST', $data);
    }

    // Picks
    public function get_picks($filters = array()) {
        $params = array(
            'language' => isset($filters['language']) ? $filters['language'] : 'en',
            'limit' => isset($filters['limit']) ? $filters['limit'] : 50,
            'offset' => isset($filters['offset']) ? $filters['offset'] : 0
        );
        
        if (isset($filters['event_id'])) {
            $params['event_id'] = $filters['event_id'];
        }
        if (isset($filters['site_id'])) {
            $params['site_id'] = $filters['site_id'];
        }
        if (isset($filters['sport_id'])) {
            $params['sport_id'] = $filters['sport_id'];
        }
        if (isset($filters['analyst_id'])) {
            $params['analyst_id'] = $filters['analyst_id'];
        }
        if (isset($filters['status'])) {
            $params['status'] = $filters['status'];
        }

        return $this->make_request('api-picks', 'GET', null, $params);
    }

    public function create_pick($data) {
        return $this->make_request('api-picks', 'POST', $data);
    }

    public function update_pick($id, $data) {
        $data['id'] = $id;
        return $this->make_request('api-picks', 'PUT', $data);
    }

    public function delete_pick($id) {
        return $this->make_request('api-picks', 'DELETE', null, array('id' => $id));
    }

    // Market Types
    public function get_market_types($sport_id = null, $language = 'en') {
        $params = array('language' => $language);
        if ($sport_id) {
            $params['sport_id'] = $sport_id;
        }
        return $this->make_request('api-market-types', 'GET', null, $params);
    }

    // Bookmakers
    public function get_bookmakers() {
        return $this->make_request('api-bookmakers');
    }

    // Analysts
    public function get_analysts() {
        return $this->make_request('api-analysts');
    }
}