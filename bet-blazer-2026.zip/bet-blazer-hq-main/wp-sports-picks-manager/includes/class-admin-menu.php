<?php
/**
 * Gerenciamento de menus do admin
 */

class SPM_Admin_Menu {
    public static function register_menus() {
        add_menu_page(
            'Sports Picks',
            'Sports Picks',
            'manage_options',
            'sports-picks',
            array(__CLASS__, 'dashboard_page'),
            'dashicons-chart-line',
            30
        );

        add_submenu_page(
            'sports-picks',
            'Events',
            'Events',
            'manage_options',
            'sports-picks-events',
            array(__CLASS__, 'events_page')
        );

        add_submenu_page(
            'sports-picks',
            'Picks',
            'Picks',
            'manage_options',
            'sports-picks-picks',
            array(__CLASS__, 'picks_page')
        );

        add_submenu_page(
            'sports-picks',
            'Settings',
            'Settings',
            'manage_options',
            'sports-picks-settings',
            array(__CLASS__, 'settings_page')
        );
    }

    public static function dashboard_page() {
        include SPM_PLUGIN_DIR . 'admin/views/dashboard.php';
    }

    public static function events_page() {
        include SPM_PLUGIN_DIR . 'admin/views/events.php';
    }

    public static function picks_page() {
        include SPM_PLUGIN_DIR . 'admin/views/picks.php';
    }

    public static function settings_page() {
        if (isset($_POST['spm_save_settings'])) {
            check_admin_referer('spm_settings_nonce');
            
            update_option('spm_api_url', sanitize_text_field($_POST['spm_api_url']));
            update_option('spm_api_key', sanitize_text_field($_POST['spm_api_key']));
            update_option('spm_default_site_id', sanitize_text_field($_POST['spm_default_site_id']));
            
            echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
        }
        
        include SPM_PLUGIN_DIR . 'admin/views/settings.php';
    }
}
