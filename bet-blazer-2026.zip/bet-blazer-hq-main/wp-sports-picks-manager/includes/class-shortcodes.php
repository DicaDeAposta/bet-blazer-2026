<?php
/**
 * Gerenciamento de shortcodes
 */

class SPM_Shortcodes {
    public static function register() {
        add_shortcode('sports_picks', array(__CLASS__, 'sports_picks_shortcode'));
        add_shortcode('event_card', array(__CLASS__, 'event_card_shortcode'));
    }

    public static function sports_picks_shortcode($atts) {
        $atts = shortcode_atts(array(
            'site_id' => '',
            'sport' => '',
            'limit' => 10,
            'layout' => 'grid'
        ), $atts);

        $api = new SPM_API_Client();
        
        $filters = array();
        if (!empty($atts['site_id'])) {
            $filters['site_id'] = $atts['site_id'];
        }
        
        $filters['from_date'] = date('Y-m-d\TH:i:s\Z');
        
        $events = $api->get_events($filters);
        
        if (isset($events['error'])) {
            return '<p>Error loading picks: ' . esc_html($events['error']) . '</p>';
        }

        ob_start();
        ?>
        <div class="spm-picks-container layout-<?php echo esc_attr($atts['layout']); ?>">
            <?php foreach (array_slice($events, 0, $atts['limit']) as $event): ?>
                <div class="spm-event-card">
                    <div class="event-header">
                        <span class="sport-badge"><?php echo esc_html($event['sport']['name']); ?></span>
                        <span class="league-name"><?php echo esc_html($event['league']['name']); ?></span>
                    </div>
                    <div class="event-teams">
                        <?php if (!empty($event['home_team']['logo_url'])): ?>
                            <img src="<?php echo esc_url($event['home_team']['logo_url']); ?>" alt="<?php echo esc_attr($event['home_team']['name']); ?>" class="team-logo">
                        <?php endif; ?>
                        <span class="home-team"><?php echo esc_html($event['home_team']['name']); ?></span>
                        <span class="vs">@</span>
                        <?php if (!empty($event['away_team']['logo_url'])): ?>
                            <img src="<?php echo esc_url($event['away_team']['logo_url']); ?>" alt="<?php echo esc_attr($event['away_team']['name']); ?>" class="team-logo">
                        <?php endif; ?>
                        <span class="away-team"><?php echo esc_html($event['away_team']['name']); ?></span>
                    </div>
                    <div class="event-datetime">
                        <?php echo esc_html(date_i18n('M j, Y @ g:i A', strtotime($event['event_datetime']))); ?>
                    </div>
                    <?php
                    $picks = $api->get_picks(array('event_id' => $event['id']));
                    if (!isset($picks['error']) && !empty($picks)):
                    ?>
                        <div class="picks-list">
                            <?php foreach ($picks as $pick): ?>
                                <div class="pick-card">
                                    <div class="pick-header">
                                        <strong><?php echo esc_html($pick['market_type']['name']); ?></strong>
                                    </div>
                                    <p class="selection"><?php echo esc_html($pick['selection']); ?></p>
                                    <div class="odds-info">
                                        <div class="odds-box">
                                            <span class="odds"><?php echo esc_html($pick['odds']); ?></span>
                                        </div>
                                        <div class="bookmaker">
                                            <?php if (!empty($pick['bookmaker']['logo_url'])): ?>
                                                <img src="<?php echo esc_url($pick['bookmaker']['logo_url']); ?>" alt="<?php echo esc_attr($pick['bookmaker']['name']); ?>">
                                            <?php else: ?>
                                                <span><?php echo esc_html($pick['bookmaker']['name']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php if (!empty($pick['analysis'])): ?>
                                        <details class="analysis">
                                            <summary>View Analysis</summary>
                                            <div class="analysis-content">
                                                <?php echo wp_kses_post($pick['analysis']); ?>
                                            </div>
                                        </details>
                                    <?php endif; ?>
                                    <?php if (!empty($pick['analyst']['display_name'])): ?>
                                        <div class="analyst-info">
                                            <?php if (!empty($pick['analyst']['avatar_url'])): ?>
                                                <img src="<?php echo esc_url($pick['analyst']['avatar_url']); ?>" alt="<?php echo esc_attr($pick['analyst']['display_name']); ?>" class="analyst-avatar">
                                            <?php endif; ?>
                                            <span class="analyst-name"><?php echo esc_html($pick['analyst']['display_name']); ?></span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function event_card_shortcode($atts) {
        $atts = shortcode_atts(array(
            'event_id' => '',
            'show_picks' => 'true'
        ), $atts);

        if (empty($atts['event_id'])) {
            return '<p>Event ID is required</p>';
        }

        $api = new SPM_API_Client();
        $events = $api->get_events(array());
        
        $event = null;
        foreach ($events as $e) {
            if ($e['id'] === $atts['event_id']) {
                $event = $e;
                break;
            }
        }

        if (!$event) {
            return '<p>Event not found</p>';
        }

        ob_start();
        ?>
        <div class="spm-event-card single">
            <div class="event-teams">
                <span class="home-team"><?php echo esc_html($event['home_team']['name']); ?></span>
                <span class="vs">vs</span>
                <span class="away-team"><?php echo esc_html($event['away_team']['name']); ?></span>
            </div>
            <div class="event-meta">
                <span class="league"><?php echo esc_html($event['league']['name']); ?></span>
                <span class="datetime"><?php echo esc_html(date_i18n('M j, Y @ g:i A', strtotime($event['event_datetime']))); ?></span>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
