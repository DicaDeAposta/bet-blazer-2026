<div class="wrap">
    <h1>Sports Picks Manager - Settings</h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('spm_settings_nonce'); ?>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="spm_api_url">Supabase API URL</label>
                </th>
                <td>
                    <input 
                        type="url" 
                        name="spm_api_url" 
                        id="spm_api_url" 
                        value="<?php echo esc_attr(get_option('spm_api_url')); ?>" 
                        class="regular-text"
                        placeholder="https://your-project.supabase.co"
                    >
                    <p class="description">Enter your Supabase project URL</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="spm_api_key">Supabase API Key</label>
                </th>
                <td>
                    <input 
                        type="text" 
                        name="spm_api_key" 
                        id="spm_api_key" 
                        value="<?php echo esc_attr(get_option('spm_api_key')); ?>" 
                        class="regular-text"
                        placeholder="your-anon-key"
                    >
                    <p class="description">Enter your Supabase anon/public key</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="spm_default_site_id">Default Site</label>
                </th>
                <td>
                    <?php
                    $api = new SPM_API_Client();
                    $sites = $api->get_sites();
                    $current_site = get_option('spm_default_site_id');
                    ?>
                    <select name="spm_default_site_id" id="spm_default_site_id" class="regular-text">
                        <option value="">Select a site</option>
                        <?php if (!isset($sites['error']) && is_array($sites)): ?>
                            <?php foreach ($sites as $site): ?>
                                <option value="<?php echo esc_attr($site['id']); ?>" <?php selected($current_site, $site['id']); ?>>
                                    <?php echo esc_html($site['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                    <p class="description">Select the default site for new content</p>
                </td>
            </tr>
        </table>
        
        <p class="submit">
            <input type="submit" name="spm_save_settings" class="button button-primary" value="Save Settings">
        </p>
    </form>
    
    <hr>
    
    <h2>Setup Instructions</h2>
    <ol>
        <li>Go to your Supabase project dashboard</li>
        <li>Navigate to Settings → API</li>
        <li>Copy the "Project URL" and paste it in the API URL field above</li>
        <li>Copy the "anon public" key and paste it in the API Key field above</li>
        <li>Save the settings</li>
        <li>Select your default site from the dropdown</li>
    </ol>
    
    <h3>Using Shortcodes</h3>
    <p>After configuration, you can use these shortcodes in your posts and pages:</p>
    <ul>
        <li><code>[sports_picks limit="5" layout="grid"]</code> - Display upcoming picks</li>
        <li><code>[event_card event_id="your-event-id"]</code> - Display a specific event</li>
    </ul>
</div>
